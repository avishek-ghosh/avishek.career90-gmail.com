# PythonHelloWorld
Very simple Python code with Flask. <br>
This repository is used in the video (https://youtu.be/iUTO_DeyhxI) for the deployment to SAP Cloud Platform - Cloud Foundry Environment.<br>

